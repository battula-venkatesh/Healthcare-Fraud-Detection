-- ============================================================
-- Healthcare Claims Fraud Detection — SQL Analysis Queries
-- Author: Battula Venkatesh
-- Run these against your PostgreSQL / MySQL / SQLite database
-- after loading cms_claims.csv into a table called `claims`
-- ============================================================


-- ── SETUP (SQLite / PostgreSQL) ──────────────────────────────
-- CREATE TABLE claims AS SELECT * FROM read_csv_auto('data/cms_claims.csv');


-- ── QUERY 1: Specialty benchmark table ───────────────────────
-- Baseline: what does "normal" look like per specialty?
SELECT
    specialty,
    COUNT(*)                                    AS provider_count,
    ROUND(AVG(claims_per_day), 2)               AS avg_claims_per_day,
    ROUND(AVG(avg_reimbursement_usd), 2)        AS avg_reimbursement,
    ROUND(AVG(denial_rate) * 100, 2)            AS avg_denial_rate_pct,
    ROUND(STDDEV(claims_per_day), 2)            AS stddev_claims
FROM claims
GROUP BY specialty
ORDER BY avg_reimbursement DESC;


-- ── QUERY 2: Providers billing 3x above specialty average ────
-- Classic red flag used by CMS Office of Inspector General
WITH spec_avg AS (
    SELECT
        specialty,
        AVG(claims_per_day) AS avg_claims
    FROM claims
    GROUP BY specialty
)
SELECT
    c.provider_id,
    c.specialty,
    c.state,
    ROUND(c.claims_per_day, 2)          AS provider_claims_per_day,
    ROUND(s.avg_claims, 2)              AS specialty_avg_claims,
    ROUND(c.claims_per_day / s.avg_claims, 2) AS deviation_ratio
FROM claims c
JOIN spec_avg s ON c.specialty = s.specialty
WHERE c.claims_per_day > (s.avg_claims * 3)
ORDER BY deviation_ratio DESC;


-- ── QUERY 3: High denial rate + high reimbursement ───────────
-- Providers that charge a lot but get denied often = billing fraud signal
SELECT
    provider_id,
    specialty,
    state,
    ROUND(avg_reimbursement_usd, 2)     AS avg_reimb,
    ROUND(denial_rate * 100, 2)         AS denial_pct,
    ROUND(claims_per_day, 2)            AS claims_per_day
FROM claims
WHERE denial_rate > 0.25
  AND avg_reimbursement_usd > (
      SELECT AVG(avg_reimbursement_usd) * 2 FROM claims
  )
ORDER BY denial_rate DESC, avg_reimb DESC
LIMIT 20;


-- ── QUERY 4: State-level fraud concentration ─────────────────
-- Which states have highest proportion of anomalous providers?
SELECT
    state,
    COUNT(*)                                        AS total_providers,
    SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END)  AS flagged_fraud,
    ROUND(
        100.0 * SUM(CASE WHEN is_fraud = 1 THEN 1 ELSE 0 END) / COUNT(*), 2
    )                                               AS fraud_rate_pct,
    ROUND(AVG(avg_reimbursement_usd), 2)            AS avg_reimb
FROM claims
GROUP BY state
ORDER BY fraud_rate_pct DESC;


-- ── QUERY 5: Patient-to-claims ratio anomaly ─────────────────
-- Low ratio = same patients billed multiple times
SELECT
    provider_id,
    specialty,
    ROUND(claims_per_day, 2)                                    AS claims_per_day,
    unique_patients,
    ROUND(CAST(unique_patients AS FLOAT) / (claims_per_day + 0.001), 3)
                                                                AS patient_claim_ratio,
    ROUND(avg_reimbursement_usd, 2)                             AS avg_reimb
FROM claims
WHERE unique_patients < claims_per_day * 0.4   -- fewer than 40% unique patients
  AND claims_per_day > 10
ORDER BY patient_claim_ratio ASC
LIMIT 20;


-- ── QUERY 6: Top 10 highest billing providers ────────────────
-- Ranked by total estimated reimbursement (claims × avg amount)
SELECT
    provider_id,
    specialty,
    state,
    ROUND(claims_per_day, 1)                                    AS daily_claims,
    ROUND(avg_reimbursement_usd, 2)                             AS avg_reimb_per_claim,
    ROUND(claims_per_day * avg_reimbursement_usd * 365, 0)      AS est_annual_billing_usd
FROM claims
ORDER BY est_annual_billing_usd DESC
LIMIT 10;


-- ── QUERY 7: Fraud rate by specialty ─────────────────────────
SELECT
    specialty,
    COUNT(*)                                        AS providers,
    SUM(is_fraud)                                   AS fraud_count,
    ROUND(100.0 * AVG(is_fraud), 2)                 AS fraud_rate_pct,
    ROUND(AVG(avg_reimbursement_usd), 2)            AS avg_reimb
FROM claims
GROUP BY specialty
ORDER BY fraud_rate_pct DESC;
