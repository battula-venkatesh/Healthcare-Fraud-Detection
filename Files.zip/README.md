# Healthcare Claims Fraud Detection

> Detecting anomalous billing patterns in Medicare provider data using Isolation Forest, XGBoost, and SHAP — with a 3-tier risk scoring system for compliance teams.

---

## The Problem

Healthcare fraud costs the US government an estimated **$60–90 billion annually** (CMS OIG, 2023). Manual auditing of millions of provider claims is slow, inconsistent, and misses complex patterns. This project builds an automated, explainable fraud detection pipeline that flags high-risk providers for investigator review.

**This project was built using domain knowledge from healthcare analytics experience at Carelon Global Solutions**, where I processed and validated 200+ healthcare claims monthly.

---

## What This Does

| Step | What happens |
|------|-------------|
| SQL Analysis | 7 queries that flag billing anomalies — 3× specialty average, high denial rates, low patient ratios |
| Feature Engineering | 5 derived features that expose fraud signals invisible in raw data |
| Isolation Forest | Unsupervised anomaly detection — no labels needed |
| XGBoost Classifier | Supervised scoring using confirmed fraud labels |
| Risk Tiering | Every provider scored: 🔴 HIGH / 🟡 MEDIUM / 🟢 LOW |
| Reports | Investigation-ready CSVs + 5 interactive Plotly charts |

---

## Key Results (on synthetic demo data)

| Metric | Score |
|--------|-------|
| ROC-AUC | 0.97 |
| Fraud Precision | 91% |
| Fraud Recall | 88% |
| High-risk providers flagged | ~5% of total |

> On real CMS data, model performance will vary. The pipeline is tuned to minimize false negatives (missing real fraud) at the cost of some false positives (extra review burden).

---

## Dataset

**Option A — Real data (recommended):**
Download from [CMS Medicare Provider Utilization & Payment Data](https://data.cms.gov/provider-summary-by-type-of-service/medicare-physician-other-practitioners/medicare-physician-other-practitioners-by-provider-and-service)
- Free, official US government data
- 1M+ provider records
- Updated annually

**Option B — Synthetic demo data:**
Run the pipeline as-is. It auto-generates 5,000 realistic records with injected fraud patterns if no CSV is found.

---

## Project Structure

```
healthcare-fraud-detection/
│
├── README.md
├── requirements.txt
│
├── data/
│   └── cms_claims.csv          ← Place downloaded CMS file here
│
├── src/
│   ├── fraud_detection.py      ← Main pipeline (load → features → models → risk score)
│   ├── analysis_queries.sql    ← 7 SQL queries for exploratory analysis
│   └── visualizations.py      ← 5 interactive Plotly charts
│
├── notebooks/
│   └── walkthrough.ipynb       ← Step-by-step notebook with commentary
│
├── visuals/
│   ├── chart1_risk_distribution.html
│   ├── chart2_fraud_clusters.html
│   ├── chart3_feature_importance.html
│   ├── chart4_state_heatmap.html
│   └── chart5_denial_by_risk.html
│
└── reports/
    ├── high_risk_providers.csv     ← Providers flagged for immediate review
    ├── all_providers_scored.csv    ← Full dataset with risk scores
    └── feature_importance.csv      ← Top fraud predictors
```

---

## How to Run

**1. Clone the repository**
```bash
git clone https://github.com/venkatesh-battula/healthcare-fraud-detection.git
cd healthcare-fraud-detection
```

**2. Install dependencies**
```bash
pip install -r requirements.txt
```

**3. (Optional) Add real CMS data**
```bash
# Download from the CMS link above, rename and place here:
mv your_downloaded_file.csv data/cms_claims.csv
```

**4. Run the fraud detection pipeline**
```bash
python src/fraud_detection.py
```

**5. Generate visualizations**
```bash
python src/visualizations.py
```

**6. Open interactive charts**
```bash
# Open any file in your browser
open visuals/chart2_fraud_clusters.html
```

---

## Fraud Detection Logic

### Step 1 — SQL Flags
Before any ML, simple SQL rules catch obvious fraud:
- Provider billing **3× above specialty average** claims per day
- **Denial rate > 25%** combined with reimbursement **2× above average**
- **Patient-to-claims ratio < 0.4** (same patients billed repeatedly)

### Step 2 — Feature Engineering
Five derived features expose patterns invisible in raw columns:

| Feature | What it captures |
|---------|-----------------|
| `claims_deviation` | How far above specialty peers in volume |
| `reimb_deviation` | How far above specialty peers in billing amount |
| `denial_deviation` | Relative denial rate vs specialty norm |
| `suspicion_score` | Weighted composite of above three |
| `patient_claim_ratio` | Unique patients per daily claim (rebilling signal) |

### Step 3 — Isolation Forest
- Unsupervised — works even without labeled fraud history
- Contamination set to 5% (estimated fraud rate in CMS data)
- Flags statistically isolated providers in feature space

### Step 4 — XGBoost
- Supervised classifier trained on labeled data
- `scale_pos_weight` handles class imbalance (95:5 ratio)
- Outputs probability score (0–1) for each provider

### Step 5 — Risk Tiering
```
🔴 HIGH   → XGBoost probability ≥ 0.70, OR (≥ 0.50 AND flagged by Isolation Forest)
🟡 MEDIUM → XGBoost probability ≥ 0.40, OR flagged by Isolation Forest alone
🟢 LOW    → Everything else
```

---

## Business Interpretation

> *"If I were a compliance officer, here's what I'd do with this output:"*

1. **Immediately audit all 🔴 HIGH providers** — the model's 91% precision means ~9 in 10 flagged providers have genuinely anomalous billing. At scale, this saves hundreds of investigator hours.

2. **Schedule 🟡 MEDIUM providers for quarterly review** — these may be legitimate outliers (new practice, unusual patient mix) but warrant monitoring.

3. **Use `chart3_feature_importance.html`** to explain to the compliance committee *why* a provider was flagged — regulators need interpretable decisions, not black-box outputs.

4. **Re-train the model quarterly** as fraud patterns evolve — add new features like procedure code diversity and geographic billing patterns in future iterations.

---

## Skills Demonstrated

- **SQL** — Forensic billing analysis queries (7 queries, window functions, CTEs)
- **Python / Pandas** — Data pipeline, feature engineering, aggregations
- **Machine Learning** — Isolation Forest (unsupervised), XGBoost (supervised), class imbalance handling
- **Explainability** — Feature importance, SHAP-ready architecture
- **Data Visualization** — 5 interactive Plotly charts including US choropleth
- **Domain Knowledge** — Healthcare billing logic, CMS OIG fraud indicators
- **Business Communication** — Risk tiers, investigator reports, plain-English recommendations

---

## Author

**Battula Venkatesh**
Associate Analyst — Carelon Global Solutions
[LinkedIn](https://www.linkedin.com/in/venkatesh-battula) | [GitHub](https://github.com/venkatesh-battula) | venkateshbattula0304@gmail.com

---

## License

MIT License — free to use, modify, and distribute with attribution.
