"""
Fraud Detection — Interactive Plotly Visualizations
====================================================
Run AFTER fraud_detection.py has generated:
  reports/all_providers_scored.csv
  reports/feature_importance.csv
"""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import os

os.makedirs("visuals", exist_ok=True)

df = pd.read_csv("reports/all_providers_scored.csv")
fi = pd.read_csv("reports/feature_importance.csv")

COLORS = {"🔴 HIGH": "#E24B4A", "🟡 MEDIUM": "#EF9F27", "🟢 LOW": "#1D9E75"}

# ── CHART 1: Risk tier distribution ──────────────────────────
tier_counts = df["risk_tier"].value_counts().reset_index()
tier_counts.columns = ["risk_tier", "count"]

fig1 = px.bar(
    tier_counts, x="risk_tier", y="count",
    color="risk_tier", color_discrete_map=COLORS,
    title="Provider Risk Tier Distribution",
    labels={"risk_tier": "Risk Tier", "count": "Number of Providers"},
    text="count"
)
fig1.update_traces(textposition="outside")
fig1.update_layout(showlegend=False, plot_bgcolor="white")
fig1.write_html("visuals/chart1_risk_distribution.html")
print("Saved: chart1_risk_distribution.html")


# ── CHART 2: Fraud probability scatter by specialty ──────────
fig2 = px.scatter(
    df,
    x="claims_per_day",
    y="avg_reimbursement_usd",
    color="risk_tier",
    color_discrete_map=COLORS,
    size="xgb_fraud_proba",
    hover_data=["provider_id", "specialty", "state", "denial_rate"],
    title="Fraud Risk Clusters — Claims vs Reimbursement",
    labels={
        "claims_per_day"        : "Claims per Day",
        "avg_reimbursement_usd" : "Avg Reimbursement (USD)",
        "risk_tier"             : "Risk Tier"
    },
    opacity=0.7
)
fig2.update_layout(plot_bgcolor="white")
fig2.write_html("visuals/chart2_fraud_clusters.html")
print("Saved: chart2_fraud_clusters.html")


# ── CHART 3: Feature importance ──────────────────────────────
fig3 = px.bar(
    fi.head(9), x="importance", y="feature",
    orientation="h",
    title="Top Fraud Predictors (XGBoost Feature Importance)",
    labels={"importance": "Importance Score", "feature": "Feature"},
    color="importance",
    color_continuous_scale="Blues"
)
fig3.update_layout(yaxis={"categoryorder": "total ascending"}, plot_bgcolor="white")
fig3.write_html("visuals/chart3_feature_importance.html")
print("Saved: chart3_feature_importance.html")


# ── CHART 4: State-level fraud heatmap ───────────────────────
state_fraud = df.groupby("state").agg(
    fraud_rate  = ("is_fraud", "mean"),
    avg_reimb   = ("avg_reimbursement_usd", "mean"),
    providers   = ("provider_id", "count")
).reset_index()

fig4 = px.choropleth(
    state_fraud,
    locations="state",
    locationmode="USA-states",
    color="fraud_rate",
    scope="usa",
    color_continuous_scale="Reds",
    title="Fraud Rate by State",
    hover_data=["providers", "avg_reimb"],
    labels={"fraud_rate": "Fraud Rate"}
)
fig4.write_html("visuals/chart4_state_heatmap.html")
print("Saved: chart4_state_heatmap.html")


# ── CHART 5: Denial rate vs fraud probability ─────────────────
fig5 = px.box(
    df, x="risk_tier", y="denial_rate",
    color="risk_tier", color_discrete_map=COLORS,
    title="Denial Rate Distribution by Risk Tier",
    labels={"denial_rate": "Claim Denial Rate", "risk_tier": "Risk Tier"},
    category_orders={"risk_tier": ["🟢 LOW", "🟡 MEDIUM", "🔴 HIGH"]}
)
fig5.update_layout(showlegend=False, plot_bgcolor="white")
fig5.write_html("visuals/chart5_denial_by_risk.html")
print("Saved: chart5_denial_by_risk.html")


print("\n✅ All 5 charts saved to /visuals/")
print("   Open any .html file in your browser to view interactive charts.")
