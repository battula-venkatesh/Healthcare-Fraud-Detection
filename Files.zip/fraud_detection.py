"""
Healthcare Claims Fraud Detection
==================================
Author  : Battula Venkatesh
LinkedIn: https://www.linkedin.com/in/venkatesh-battula
GitHub  : https://github.com/venkatesh-battula

Detects anomalous billing patterns in healthcare claims using:
  - SQL-style aggregations (pandas)
  - Isolation Forest (unsupervised anomaly detection)
  - XGBoost (supervised scoring)
  - SHAP (explainability)
  - Risk scoring: Low / Medium / High
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
import xgboost as xgb
import warnings
warnings.filterwarnings("ignore")

# ── 1. LOAD DATA ──────────────────────────────────────────────────────────────

def load_data(path: str = "data/cms_claims.csv") -> pd.DataFrame:
    """
    Load CMS Medicare Provider Utilization dataset.
    Download from:
    https://data.cms.gov/provider-summary-by-type-of-service/medicare-physician-other-practitioners/medicare-physician-other-practitioners-by-provider-and-service
    
    Falls back to synthetic data if file not found (for demo purposes).
    """
    try:
        df = pd.read_csv(path, low_memory=False)
        print(f"Loaded {len(df):,} records from {path}")
        return df
    except FileNotFoundError:
        print("CMS file not found — generating synthetic demo data...")
        return generate_synthetic_data()


def generate_synthetic_data(n: int = 5000, seed: int = 42) -> pd.DataFrame:
    """
    Generates realistic synthetic healthcare claims data for demo/testing.
    Injects ~5% fraudulent records with extreme billing patterns.
    """
    np.random.seed(seed)
    specialties = [
        "Internal Medicine", "Family Practice", "Cardiology",
        "Orthopedic Surgery", "Psychiatry", "Dermatology",
        "Ophthalmology", "Neurology", "Oncology", "Radiology"
    ]
    specialty_avg_reimbursement = {
        "Internal Medicine": 85, "Family Practice": 70, "Cardiology": 320,
        "Orthopedic Surgery": 450, "Psychiatry": 110, "Dermatology": 140,
        "Ophthalmology": 200, "Neurology": 180, "Oncology": 600, "Radiology": 250
    }

    records = []
    for i in range(n):
        is_fraud = np.random.random() < 0.05  # 5% fraud rate
        spec = np.random.choice(specialties)
        base_reimb = specialty_avg_reimbursement[spec]

        if is_fraud:
            claims_per_day  = np.random.uniform(40, 100)   # impossibly high
            avg_reimb       = base_reimb * np.random.uniform(3.5, 6.0)
            unique_patients = int(claims_per_day * np.random.uniform(0.3, 0.5))
            denial_rate     = np.random.uniform(0.25, 0.60)
        else:
            claims_per_day  = np.random.uniform(1, 20)
            avg_reimb       = base_reimb * np.random.uniform(0.7, 1.4)
            unique_patients = int(claims_per_day * np.random.uniform(0.8, 1.0))
            denial_rate     = np.random.uniform(0.02, 0.15)

        records.append({
            "provider_id"           : f"PRV{i:05d}",
            "specialty"             : spec,
            "claims_per_day"        : round(claims_per_day, 2),
            "avg_reimbursement_usd" : round(avg_reimb, 2),
            "unique_patients"       : unique_patients,
            "denial_rate"           : round(denial_rate, 3),
            "years_in_practice"     : np.random.randint(1, 35),
            "state"                 : np.random.choice(["CA","TX","NY","FL","IL","PA","OH","GA","NC","MI"]),
            "is_fraud"              : int(is_fraud)
        })

    df = pd.DataFrame(records)
    df.to_csv("data/cms_claims.csv", index=False)
    print(f"Generated {len(df):,} synthetic records (fraud rate: {df['is_fraud'].mean():.1%})")
    return df


# ── 2. FEATURE ENGINEERING ───────────────────────────────────────────────────

def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Creates derived features that expose fraudulent billing patterns.
    These mirror real forensic analytics used by CMS and OIG.
    """
    # Specialty-level benchmarks (SQL GROUP BY equivalent)
    spec_stats = df.groupby("specialty").agg(
        spec_avg_claims    = ("claims_per_day",        "mean"),
        spec_avg_reimb     = ("avg_reimbursement_usd", "mean"),
        spec_avg_denial    = ("denial_rate",           "mean")
    ).reset_index()

    df = df.merge(spec_stats, on="specialty", how="left")

    # Deviation scores — how far is this provider from their specialty peers?
    df["claims_deviation"]  = df["claims_per_day"]        / df["spec_avg_claims"]
    df["reimb_deviation"]   = df["avg_reimbursement_usd"] / df["spec_avg_reimb"]
    df["denial_deviation"]  = df["denial_rate"]           / df["spec_avg_denial"]

    # Composite suspicion score (domain-informed heuristic)
    df["suspicion_score"] = (
        df["claims_deviation"] * 0.40 +
        df["reimb_deviation"]  * 0.35 +
        df["denial_deviation"] * 0.25
    )

    # Patient-to-claims ratio (low ratio = same patients billed repeatedly)
    df["patient_claim_ratio"] = df["unique_patients"] / (df["claims_per_day"] + 1e-6)

    return df


# ── 3. ISOLATION FOREST (UNSUPERVISED) ───────────────────────────────────────

def run_isolation_forest(df: pd.DataFrame) -> pd.DataFrame:
    """
    Unsupervised anomaly detection — no labels needed.
    Useful when you don't have confirmed fraud history.
    """
    features = [
        "claims_per_day", "avg_reimbursement_usd", "denial_rate",
        "claims_deviation", "reimb_deviation", "denial_deviation",
        "suspicion_score", "patient_claim_ratio"
    ]

    X = df[features].fillna(0)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    iso = IsolationForest(
        n_estimators=200,
        contamination=0.05,   # expected fraud rate
        random_state=42
    )
    df["anomaly_score"]    = iso.decision_function(X_scaled)   # lower = more anomalous
    df["iso_fraud_flag"]   = (iso.predict(X_scaled) == -1).astype(int)

    print(f"\nIsolation Forest flagged {df['iso_fraud_flag'].sum():,} anomalies "
          f"({df['iso_fraud_flag'].mean():.1%} of providers)")
    return df


# ── 4. XGBOOST (SUPERVISED) ──────────────────────────────────────────────────

def run_xgboost(df: pd.DataFrame) -> tuple:
    """
    Supervised fraud classifier using XGBoost.
    Requires labeled data (is_fraud column).
    Returns trained model + feature importance dataframe.
    """
    features = [
        "claims_per_day", "avg_reimbursement_usd", "denial_rate",
        "years_in_practice", "claims_deviation", "reimb_deviation",
        "denial_deviation", "suspicion_score", "patient_claim_ratio"
    ]
    target = "is_fraud"

    X = df[features].fillna(0)
    y = df[target]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()

    model = xgb.XGBClassifier(
        n_estimators=300,
        max_depth=5,
        learning_rate=0.05,
        scale_pos_weight=scale_pos_weight,   # handles class imbalance
        eval_metric="auc",
        random_state=42,
        verbosity=0
    )
    model.fit(X_train, y_train,
              eval_set=[(X_test, y_test)],
              verbose=False)

    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    print("\n── XGBoost Results ──────────────────────────────")
    print(classification_report(y_test, y_pred, target_names=["Legit", "Fraud"]))
    print(f"ROC-AUC Score: {roc_auc_score(y_test, y_proba):.4f}")

    # Full dataset fraud probability
    df["xgb_fraud_proba"] = model.predict_proba(X)[:, 1]

    # Feature importance
    fi = pd.DataFrame({
        "feature"   : features,
        "importance": model.feature_importances_
    }).sort_values("importance", ascending=False)

    return model, df, fi


# ── 5. RISK SCORING ──────────────────────────────────────────────────────────

def assign_risk_tier(df: pd.DataFrame) -> pd.DataFrame:
    """
    Combines Isolation Forest + XGBoost into a 3-tier risk label.
    Mirrors how real compliance teams triage alerts.
    """
    def risk_label(row):
        p = row["xgb_fraud_proba"]
        iso = row["iso_fraud_flag"]
        if p >= 0.70 or (p >= 0.50 and iso == 1):
            return "🔴 HIGH"
        elif p >= 0.40 or iso == 1:
            return "🟡 MEDIUM"
        else:
            return "🟢 LOW"

    df["risk_tier"] = df.apply(risk_label, axis=1)

    print("\n── Risk Distribution ────────────────────────────")
    print(df["risk_tier"].value_counts().to_string())
    return df


# ── 6. BUSINESS REPORT ───────────────────────────────────────────────────────

def generate_report(df: pd.DataFrame, fi: pd.DataFrame) -> None:
    """
    Saves investigation-ready CSV reports.
    """
    # High-risk providers for investigator review
    high_risk = (
        df[df["risk_tier"] == "🔴 HIGH"]
        .sort_values("xgb_fraud_proba", ascending=False)
        [[
            "provider_id", "specialty", "state",
            "claims_per_day", "avg_reimbursement_usd", "denial_rate",
            "suspicion_score", "xgb_fraud_proba", "risk_tier"
        ]]
    )
    high_risk.to_csv("reports/high_risk_providers.csv", index=False)

    # Full scored dataset
    df.to_csv("reports/all_providers_scored.csv", index=False)

    # Feature importance
    fi.to_csv("reports/feature_importance.csv", index=False)

    print(f"\nReports saved to /reports/")
    print(f"  high_risk_providers.csv  → {len(high_risk):,} providers flagged for review")
    print(f"  all_providers_scored.csv → full dataset with risk scores")
    print(f"  feature_importance.csv   → top fraud predictors")

    print("\n── Top 5 High-Risk Providers ────────────────────")
    print(high_risk.head().to_string(index=False))


# ── 7. MAIN ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 55)
    print("  Healthcare Claims Fraud Detection Pipeline")
    print("  Battula Venkatesh | github.com/venkatesh-battula")
    print("=" * 55)

    df = load_data("data/cms_claims.csv")
    df = engineer_features(df)
    df = run_isolation_forest(df)
    model, df, fi = run_xgboost(df)
    df = assign_risk_tier(df)
    generate_report(df, fi)

    print("\n✅ Pipeline complete. Check /reports/ for output files.")
